using Biblioteca.Models;
using Microsoft.AspNetCore.Mvc;

namespace Biblioteca.Controllers;

public class BibliotecaController : Controller
{
    List<Livro> l1 = new List<Livro>()
        {
            new Livro
            {
                Id = 0, 
                Titulo = "A dona da casa perfeita",
                NumPaginas = 366,
                Autor = new Autor
                {
                    Id = 0,
                    Nome = "Liane Child",
                    Biografia = "Liane Child é uma autora americana conhecida por seus romances emocionantes e envolventes. Ela nasceu em 1969, em Nova York. Seu livro mais famoso é 'A dona da casa perfeita', que foi adaptado para o cinema em 2022. A autora é conhecida por criar personagens complexos e histórias que exploram temas como amor, perda e superação.",
                    DataNascimento = new DateOnly(1969, 01, 01),
                    ImagemUrl = "lidona.webp"
                },
                Genero = "Suspense",
                DataPublicacao = new DateOnly(2022, 03, 15),
                ImagemUrl = "donaperfeita.jpg",
                Sinopse = "Uma mulher aparentemente comum leva uma vida tranquila cuidando da casa e da família, sendo vista como a “dona de casa perfeita”. Porém, por trás dessa rotina organizada, existem segredos sombrios e comportamentos perturbadores. Conforme a história avança, revelações inesperadas mostram que nem tudo é o que parece, criando um clima de tensão e desconfiança típico de um thriller psicológico" 

            },
            new Livro
            {
                Id = 1,
                Titulo = "Depois de você",
                NumPaginas = 320,
                Autor = new Autor
                {
                    Id = 1,
                    Nome = "Jojo Moyes",
                    Biografia = "Jojo Moyes é uma autora britânica conhecida por seus romances emocionantes e envolventes. Ela nasceu em 4 de agosto de 1969, em Londres, Inglaterra. Antes de se tornar escritora em tempo integral, Moyes trabalhou como jornalista e editora. Seu livro mais famoso é 'Como Eu Era Antes de Você', que foi adaptado para o cinema em 2016. A autora é conhecida por criar personagens complexos e histórias que exploram temas como amor, perda e superação.",
                    DataNascimento = new DateOnly(1969, 08, 04),
                    ImagemUrl = "depvauto.jpg"
                },
                Genero = "Romance / Drama",
                DataPublicacao = new DateOnly(2015, 09, 24),
                ImagemUrl = "depvo.jpg",
                Sinopse = "Depois de Você é a sequência do best-seller Como Eu Era Antes de Você. A história continua a seguir Louisa Clark, que após os eventos do primeiro livro, enfrenta novos desafios e tenta encontrar um novo propósito em sua vida. O romance e o drama se entrelaçam enquanto Louisa lida com as consequências de suas escolhas e busca um caminho para a felicidade novamente."
            },
            new Livro
            {
                Id = 2,    
                Titulo = "Drácula",
                NumPaginas = 418,
                Autor = new Autor
                {
                    Id = 2,
                    Nome = "Bram Stoker",
                    Biografia = "Bram Stoker foi um escritor irlandês, mais conhecido por seu romance 'Drácula', publicado em 1897. Ele nasceu em 1847, em Dublin, Irlanda. Stoker trabalhou como ator e jornalista antes de se tornar escritor. 'Drácula' é considerado um clássico da literatura de terror gótico e influenciou muitas obras subsequentes.",
                    DataNascimento = new DateOnly(1847, 11, 08),
                    ImagemUrl = "bram.jpg"
                },
                Genero = "Terror gótico",
                DataPublicacao = new DateOnly(1897, 05, 26),
                ImagemUrl = "dracu.jpg.png",
                Sinopse = "Drácula é um clássico da literatura de terror gótico, escrito por Bram Stoker. A história gira em torno do conde Drácula, um vampiro que se muda da Transilvânia para a Inglaterra em busca de novas vítimas. O livro é narrado por meio de diários, cartas e relatos de personagens, criando uma atmosfera sombria e assustadora. Drácula é conhecido por sua habilidade de se transformar em morcego, controlar animais e hipnotizar suas vítimas, tornando-se um dos vilões mais icônicos da literatura."
                
            },
            new Livro
            {
                Id = 3,
                Titulo = "Beleza Feroz",
                NumPaginas = 352,
                Autor = new Autor
                {
                    Id = 3,
                    Nome = "Jennifer Donnelly",
                    Biografia = "Jennifer Donnelly é uma autora americana conhecida por seus romances emocionantes e envolventes. Ela nasceu em 1969, em Nova York. Seu livro mais famoso é 'A dona da casa perfeita', que foi adaptado para o cinema em 2022. A autora é conhecida por criar personagens complexos e histórias que exploram temas como amor, perda e superação.",
                    DataNascimento = new DateOnly(1969, 01, 01),
                    ImagemUrl = "jeni.jpg"
                },
                Genero = "Fantasia ",
                DataPublicacao = new DateOnly(2019, 05, 28),
                ImagemUrl = "bele.jpg",
                Sinopse = "A história reconta o conto da Cinderela pelo ponto de vista de uma de suas irmãs postiças, considerada “feia” e rejeitada. Ao longo da narrativa, ela enfrenta julgamentos, padrões de beleza e seu próprio destino, questionando o que realmente significa ser bela e digna. É uma história sobre identidade, escolhas e autoconfiança."

            },
            new Livro
            {
                Id = 4,
                Titulo = "O Pequeno Príncipe",
                NumPaginas = 96 ,
                Autor = new Autor
                {
                    Id = 4,
                    Nome = "Antoine de Saint-Exupéry",
                    Biografia = "Antoine de Saint-Exupéry foi um escritor e piloto francês, mais conhecido por seu romance 'O Pequeno Príncipe', publicado em 1943. Ele nasceu em 1900, em Lyon, França. Saint-Exupéry trabalhou como piloto antes de se tornar escritor. 'O Pequeno Príncipe' é considerado um clássico da literatura infantil e aborda temas universais de maneira acessível para leitores de todas as idades.",
                    DataNascimento = new DateOnly(1900, 06, 29),
                    ImagemUrl = "pqauto.jpg"
                },
                Genero = " Literatura infantil ",
                DataPublicacao = new DateOnly(1943, 04, 06),
                ImagemUrl = "pq.jpg",
                Sinopse = "O Pequeno Príncipe é um clássico da literatura infantil escrito por Antoine de Saint-Exupéry. A história segue um jovem príncipe que viaja por diferentes planetas, encontrando personagens peculiares e aprendendo lições valiosas sobre a vida, o amor e a amizade. O livro é conhecido por sua simplicidade poética e profundidade filosófica, abordando temas universais de maneira acessível para leitores de todas as idades."
            
            }
        };
    public IActionResult Index()
    {
        return View(l1);
    }
     public IActionResult Livro(int id)
     {
        var livro = l1.FirstOrDefault(l => l.Id == id);
        if (livro == null)
        {
            return NotFound();
        }
        return View(livro);
     }
     
 public IActionResult Autor(int idautor)
{
    // 1. Criamos uma lista só com os autores (sem repetir e sem nulos)
    // Isso evita que o código tente ler dados de onde não existe
    var autor = l1.Where(l => l.Autor != null)
                  .Select(l => l.Autor)
                  .FirstOrDefault(a => a!.Id == idautor);

    // 2. Se o autor não for encontrado, o NotFound() impede o Erro 500
    if (autor == null)
    {
        return NotFound("Ops! Esse autor não foi encontrado em nossa biblioteca.");
    }

    // 3. Se tudo estiver certo, ele envia o autor para a View
    return View(autor);
}
}